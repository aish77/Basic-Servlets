package com.topic3.assignment1;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletRedirect")
public class ServletRedirect extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
// This is the main servlet linked to the login page which redirects to the First servlet, Second Servlet and Third servlet based on the user input 


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int a = Integer.parseInt(request.getParameter("input1"));
		if (a < 10) {
			response.sendRedirect("FirstServlet");
		} else if (a > 10 && a < 99) {
			response.sendRedirect("SecondServlet");
		} else {
			response.sendRedirect("ThirdServlet");
		}
	}

}
