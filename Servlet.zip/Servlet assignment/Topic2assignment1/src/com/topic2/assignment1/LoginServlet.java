package com.topic2.assignment1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();	
// getting the username and password enterd in the login form
		
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
//		establishing connection with the database
// created table in MySQL with column heading UerName and password
// entered 2 rows with values (abc, test) and (xyz, abc)		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root", "test");

			Statement statement = con.createStatement();
// comparing the entered username and password with the one in the database for the validation
// passing the username as a attibute for the welcome message in the home servlet page
// printing error if the login is unsuccessful
			ResultSet resultSet = statement.executeQuery(
					"select * from user where userName='"+userName +"' and password='"+password+"'");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("homeServlet");
			if (resultSet.next()) {
				request.setAttribute("message", "Welcome  " + userName);
				requestDispatcher.forward(request, response);
			} 
			else 
			    {
				out.print("<h1>Login Error </h1>");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
