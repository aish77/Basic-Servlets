

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();	
// getting values for the parameters entered in the form
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String usertype = request.getParameter("dropdown");
// establishing connection with the database
// created table named company in the MySql database with the column headings username , password and usertype
//table values as follows 
// (aishwary), (test), (E)
// (ramesh), (testing), (A)
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root", "test");

			Statement statement = con.createStatement();
// comparing all the three values as per the database and redirecting to the admin and employee servlet pages accordingly			
			ResultSet resultSet = statement.executeQuery(
					"select * from company where username='"+username +"' and password='"+password+"' and usertype='"+usertype+"'");
			
			if (resultSet.next()) {
				String S1= resultSet.getString(3);
				if(S1.equals("A")) {
				response.sendRedirect("HomeServletAdmin");
			}
				else{
					response.sendRedirect("HomeServletEmployee");
				}	
			}
			else 
			    {
				out.println("Login Error");

			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
