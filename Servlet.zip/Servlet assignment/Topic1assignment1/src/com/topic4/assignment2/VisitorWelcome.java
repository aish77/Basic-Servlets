package com.topic4.assignment2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/VisitorWelcome")
public class VisitorWelcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static int i = 1;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
// using cookies to store the visit value fist time it shows welcome user and after reloading page welcome back
//page can be reloaded as much as possible to print welcome back		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String k = String.valueOf(i);
		Cookie c = new Cookie("visit", k);
		response.addCookie(c);
		int j = Integer.parseInt(c.getValue());
		if (j == 1) {
			out.println("Welcome New User");
		} else {
			out.println("Welcome Back");
		}
		i++;
	}

}
