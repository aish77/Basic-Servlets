package com.tiopic4.assignment1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
//getting the values from the form 		
		String userName = request.getParameter("username");
		String Password = request.getParameter("password");
		
//Creating cookies and storing the value of the cookies 		
		Cookie User = new Cookie("username", userName);
		
		Cookie Pass = new Cookie("password", Password);
		
		response.addCookie(User);
		response.addCookie(Pass);
//getting the cookies		
		Cookie ck[]=request.getCookies();
		String userNameValue = ck[1].getValue();
		String passwordValue = ck[0].getValue();
//checking the cookies with the avaiable values in the database
// database with name user is created in MySql with 2 column headings userName and password		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root", "test");

			Statement statement = con.createStatement();
			
			ResultSet resultSet = statement.executeQuery(
					"select * from user where userName='"+userNameValue +"' and password='"+passwordValue+"'");
			if(resultSet.next()) {
				out.println("Cookie Username: "+userNameValue +"Cookie Password: "+passwordValue+"     Login Successful");
			}
			else {
				out.println("Cookie Username: "+userNameValue +"Cookie Password: "+passwordValue+"Login Error");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		

	
	}

}
