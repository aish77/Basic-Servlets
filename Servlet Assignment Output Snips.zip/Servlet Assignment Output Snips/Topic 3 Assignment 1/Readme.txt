snip 1 -- shows the input page
snip 2 -- shows the entry of value of input less than 10
snip 3 -- shows servlet page 1 for value less than 10
snip 4 -- shows another value less than 10
snip 5 -- shows the servlet page 1 for the value less than 10
snip 6 -- shows the input number grater than 10
snip 7 -- shows the servlet page 2 for input greater than 10
snip 8 -- shows another value less than 99
snip 9 -- shows the servlet page 2 for the input less than 99
snip 10 -- shows the entry more than 99
snip 11 -- error page for entry more than 99
snip 12 -- shows another entry more than 99
snip 13 -- shows error page for the entry more than 99
