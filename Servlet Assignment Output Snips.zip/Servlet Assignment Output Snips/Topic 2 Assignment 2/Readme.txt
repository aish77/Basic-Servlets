snip 1 -- shows the login homepage
snip 2 -- shows the entry as per the first employee type entry in the database
snip 3 -- shows the successful login page of employee
snip 4 -- shows the entry as per the Admin user type entry in the database
snip 5 -- shows the successful login page of the admin
snip 6 -- shows the login with incorrect credentials for admin homepage
snip 7 -- shows error for the admin homepage
snip 8 -- shows the incorrect credentials for the employee homepage
snip 9 -- shows the error page for the empoyee homepage

MySql database snip -- shows the database used for the testing