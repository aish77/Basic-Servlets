snip 1 -- shows new user welcome message
snip 2 -- shows the welcome back message for the same user