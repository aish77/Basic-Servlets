snip 1 -- shows the login page
snip 2 -- shows the correct value entered as per the database
snip 3 -- shows the successful login message
snip 4 -- shows the another correct value entered as per the database
snip 5 -- shows the successfull login page as per the login page showing the username and password values with the help of database
snip 6 -- shows the incorrect values entered for login
snip 7 -- shows the login error
snip 8 -- shows another incorrect values entered for the login
snip 9 -- shows error for the incorrect values