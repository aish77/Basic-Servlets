Snip 1 -- shows the login homepage
Snip 2 -- username and password as per the database table user, database snips also attached
Snip 3 -- Successful Login page
Snip 4 -- username and password as per the second entry in the database
Snip 5 -- Successful Login page
Snip 6 -- Login as per the incorrect username and password
Snip 7 -- Login Error page displayed
